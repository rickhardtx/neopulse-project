@echo off
set "JAVA_HOME=C:\Program Files\Amazon Corretto\jdk21.0.12_8"
cd /d "C:\Users\rickh\OneDrive\Documentos\NeoPulse (Proyecto)\neopulse-project\neopulse-backend"
"%JAVA_HOME%\bin\java.exe" -jar target\neopulse-backend-0.0.1-SNAPSHOT.jar
