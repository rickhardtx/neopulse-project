package neopulse_backend.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "categoria")
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_categoria")
    private Integer id;

    @JsonProperty("nombre")
    @Column(name = "nombre", length = 50, nullable = false)
    private String name;

    @JsonProperty("descripcion")
    @Column(name = "descripcion", length = 150)
    private String description;

    // Constructor vacío requerido por JPA
    public Categoria() {
    }

    // ==========================================================================
    // GETTERS Y SETTERS MANUALES (Para garantizar la compilación)
    // ==========================================================================

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
