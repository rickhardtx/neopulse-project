package neopulse_backend.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;

@Entity
@Table(name = "producto")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_producto")
    private Integer id;

    @JsonProperty("nombre")
    @Column(name = "nombre", length = 100, nullable = false)
    private String name;

    @JsonProperty("descripcion")
    @Column(name = "descripcion", length = 250)
    private String description;

    @JsonProperty("precio")
    @Column(name = "precio", nullable = false)
    private BigDecimal price;

    @JsonProperty("stock")
    @Column(name = "stock", nullable = false)
    private Integer stock;

    @JsonProperty("imagen")
    @Column(name = "imagen", length = 255)
    private String image;

    @ManyToOne
    @JoinColumn(name = "id_categoria")
    @JsonProperty("categoria")
    private Categoria categoria;

    @JsonProperty("disponible")
    @Column(name = "disponible", nullable = false, columnDefinition = "TINYINT(1) DEFAULT 1")
    private boolean disponible = true;

    // Constructor vacío requerido por JPA
    public Producto() {
    }

    // ==========================================================================
    // GETTERS Y SETTERS MANUALES (Para garantizar la compilación)
    // ==========================================================================

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
}
