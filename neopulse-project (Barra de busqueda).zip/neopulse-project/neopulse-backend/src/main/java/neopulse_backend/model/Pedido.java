package neopulse_backend.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "pedido")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pedido")
    private Integer id;

    @JsonProperty("fecha")
    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    @JsonProperty("estado")
    @Column(name = "estado", length = 30, nullable = false)
    private String estado;

    @JsonProperty("total")
    @Column(name = "total", nullable = false)
    private BigDecimal total;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    @JsonProperty("usuario")
    private User usuario;

    @Transient
    @JsonProperty("detalles")
    private java.util.List<DetallePedido> detalles;

    public Pedido() {
        this.fecha = LocalDate.now();
        this.estado = "Pendiente";
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal total) { this.total = total; }
    public User getUsuario() { return usuario; }
    public void setUsuario(User usuario) { this.usuario = usuario; }
    public java.util.List<DetallePedido> getDetalles() { return detalles; }
    public void setDetalles(java.util.List<DetallePedido> detalles) { this.detalles = detalles; }
}
