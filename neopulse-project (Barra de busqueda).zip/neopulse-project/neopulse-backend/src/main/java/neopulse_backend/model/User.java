package neopulse_backend.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "usuario")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private Integer id;

    @JsonProperty("nombre")
    @Column(name = "nombre", length = 100, nullable = false)
    private String name;

    @JsonProperty("correo")
    @Column(name = "correo_electronico", length = 100, nullable = false, unique = true)
    private String email;

    @JsonIgnore
    @JsonProperty("contrasena")
    @Column(name = "contrasena", length = 255, nullable = false)
    private String password;

    @JsonProperty("telefono")
    @Column(name = "telefono", length = 20, nullable = false)
    private String phone;

    @JsonProperty("rol")
    @Column(name = "rol", length = 20, nullable = false)
    private String role = "cliente";

  
    @Column(name = "id_carrito")
    private Integer cartId;

    // Constructor vacío requerido por JPA
    public User() {
    }

    // ==========================================================================
    // GETTERS Y SETTERS MANUALES (Para garantizar la compilación)
    // ==========================================================================

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}