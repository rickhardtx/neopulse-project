package neopulse_backend.config;

import neopulse_backend.model.Categoria;
import neopulse_backend.model.Producto;
import neopulse_backend.model.User;
import neopulse_backend.repository.CategoriaRepository;
import neopulse_backend.repository.ProductoRepository;
import neopulse_backend.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Siembra las categorías y productos iniciales de NeoPulse al levantar el backend.
 * Solo actúa cuando la tabla de productos está vacía, por lo que es idempotente.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public void run(String... args) {
        sembrarAdmin();
        if (productoRepository.count() > 0) {
            log.info("La base de datos ya contiene productos; se omite la siembra inicial.");
            return;
        }

        log.info("Sembrando categorías y productos iniciales de NeoPulse...");

        Categoria teclados = buscarOCrearCategoria("Teclados",
                "Teclados mecánicos y de membrana para tu setup gaming.");
        Categoria mouses = buscarOCrearCategoria("Mouses",
                "Mouses gaming con sensor de alta precisión y diseño ergonómico.");
        Categoria mousepads = buscarOCrearCategoria("Mousepads",
                "Mousepads XXL y con retroiluminación para máxima precisión.");
        Categoria audio = buscarOCrearCategoria("Audífonos y Cornetas",
                "Audio envolvente y sonido para tu experiencia gaming.");
        Categoria monitores = buscarOCrearCategoria("Monitores",
                "Monitores de alta frecuencia de refresco para gaming.");
        Categoria accesorios = buscarOCrearCategoria("Accesorios",
                "Accesorios y extras para completar tu setup NeoPulse.");

        crearProducto("Teclado mecanico K-MK200",
                "Teclado mecánico con retroiluminación RGB, ideal para gaming.",
                new BigDecimal("100000"), 25, "teclado.png", teclados, true);
        crearProducto("Mouse alambrico M-ECG500",
                "Mouse gaming con sensor de alta precisión y diseño ergonómico.",
                new BigDecimal("72000"), 30, "mouse.png", mouses, true);
        crearProducto("Mousepad RGB NeoPulse XXL",
                "Mousepad XXL con retroiluminación RGB y superficie de microtejido.",
                new BigDecimal("45000"), 18, "mousepad.png", mousepads, false);
        crearProducto("Cornetas Gaming CP-X9",
                "Cornetas 2.1 con graves potentes para inmersión total.",
                new BigDecimal("55000"), 15, "cornetas.png", audio, false);
        crearProducto("Audifonos Alambricos G-HP100",
                "Audífonos over-ear con sonido envolvente y micrófono integrado.",
                new BigDecimal("65000"), 20, "audifonos.png", audio, true);
        crearProducto("Monitor Gamer MG-27 144Hz",
                "Monitor de 27 pulgadas, panel IPS y 144 Hz de refresco.",
                new BigDecimal("850000"), 8, "", monitores, true);
        crearProducto("Kit Accesorios Gamer NP-A01",
                "Kit de accesorios gaming: grips, cable organizador y soportes.",
                new BigDecimal("25000"), 40, "", accesorios, true);

        log.info("Siembra inicial de catálogo completada.");
    }

    // Reutiliza la categoría si ya existe, de lo contrario la crea
    private Categoria buscarOCrearCategoria(String nombre, String descripcion) {
        return categoriaRepository.findByName(nombre).orElseGet(() -> {
            Categoria categoria = new Categoria();
            categoria.setName(nombre);
            categoria.setDescription(descripcion);
            return categoriaRepository.save(categoria);
        });
    }

    private void crearProducto(String nombre, String descripcion, BigDecimal precio, Integer stock,
                                String imagen, Categoria categoria, boolean disponible) {
        Producto producto = new Producto();
        producto.setName(nombre);
        producto.setDescription(descripcion);
        producto.setPrice(precio);
        producto.setStock(stock);
        producto.setImage(imagen);
        producto.setCategoria(categoria);
        producto.setDisponible(disponible);
        productoRepository.save(producto);
    }

    private void sembrarAdmin() {
        if (userRepository.findByEmail("admin@neopulse.com").isPresent()) return;
        User admin = new User();
        admin.setName("Administrador");
        admin.setEmail("admin@neopulse.com");
        admin.setPhone("3000000000");
        admin.setRole("admin");
        String contrasenaEncriptada;
        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest("admin123".getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            contrasenaEncriptada = hexString.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new RuntimeException("Error al encriptar la contraseña del admin", e);
        }
        admin.setPassword(contrasenaEncriptada);
        userRepository.save(admin);
        log.info("Usuario administrador creado: admin@neopulse.com / admin123");
    }
}
