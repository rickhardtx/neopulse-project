package neopulse_backend.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Asegura que la columna "disponible" exista en la tabla "producto" al arrancar.
 * El backend usa ddl-auto=none, así que la estructura no se genera sola.
 * Si la columna falta, la crea y marca como "Próximamente" los productos 3 y 4
 * (Mousepad y Cornetas), manteniendo la coherencia con la vitrina.
 *
 * Se ejecuta con la máxima prioridad para correr antes que DataInitializer,
 * que inserta productos con el campo "disponible".
 */
@Component
@Order(1)
public class DisponibleColumnInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DisponibleColumnInitializer.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) {
        try {
            Integer count = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS " +
                            "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'producto' AND COLUMN_NAME = 'disponible'",
                    Integer.class);

            if (count != null && count == 0) {
                jdbcTemplate.execute(
                        "ALTER TABLE producto ADD COLUMN disponible TINYINT(1) NOT NULL DEFAULT 1");
                // Productos de la sección "Próximamente" (Mousepad RGB y Cornetas Gaming)
                jdbcTemplate.update(
                        "UPDATE producto SET disponible = 0 WHERE id_producto IN (3, 4)");
                log.info("Columna 'disponible' creada en 'producto' y marcados los productos próximos.");
            }
        } catch (Exception e) {
            // Si la tabla aún no existe o el motor no soporta INFORMATION_SCHEMA,
            // se registra pero no se detiene el arranque.
            log.warn("No se pudo verificar/crear la columna 'disponible' en este arranque: {}", e.getMessage());
        }
    }
}
