package neopulse_backend.service;

import neopulse_backend.model.User;
import neopulse_backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Verifica si el correo ya existe apoyándose en findByEmail
    public boolean existsByCorreo(String email) {
        return userRepository.findByEmail(email).isPresent();
    }

    // Busca un usuario por correo para el inicio de sesión
    public User findByCorreo(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }

    // Devuelve todos los usuarios registrados
    public java.util.List<User> listarUsuarios() {
        return userRepository.findAll();
    }

    // Registra al usuario aplicando hash SHA-256 a la contraseña antes de guardarlo
    public User saveUser(User user) {
        String contrasenaEncriptada = encriptarSHA256(user.getPassword());
        user.setPassword(contrasenaEncriptada);
        return userRepository.save(user);
    }

    // Compara la contraseña en texto plano con el hash almacenado
    public boolean checkPassword(String contrasenaPlana, String contrasenaEncriptada) {
        String hashPlana = encriptarSHA256(contrasenaPlana);
        return hashPlana.equals(contrasenaEncriptada);
    }

    // Función auxiliar nativa para encriptar en SHA-256
    private String encriptarSHA256(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error al encriptar la contraseña", e);
        }
    }
}