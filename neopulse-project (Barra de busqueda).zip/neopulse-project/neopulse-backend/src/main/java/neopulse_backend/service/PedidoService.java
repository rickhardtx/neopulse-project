package neopulse_backend.service;

import neopulse_backend.model.DetallePedido;
import neopulse_backend.model.Pedido;
import neopulse_backend.model.Producto;
import neopulse_backend.model.User;
import neopulse_backend.repository.DetallePedidoRepository;
import neopulse_backend.repository.PedidoRepository;
import neopulse_backend.repository.ProductoRepository;
import neopulse_backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private DetallePedidoRepository detallePedidoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private UserRepository userRepository;

    @Transactional
    public Pedido crearPedido(Integer usuarioId, List<Map<String, Object>> items, String direccion) {
        Optional<User> userOpt = userRepository.findById(usuarioId);
        if (userOpt.isEmpty()) throw new RuntimeException("Usuario no encontrado.");

        Pedido pedido = new Pedido();
        pedido.setUsuario(userOpt.get());
        pedido.setFecha(LocalDate.now());
        pedido.setEstado("Pendiente");
        pedido.setTotal(BigDecimal.ZERO);

        Pedido guardado = pedidoRepository.save(pedido);

        BigDecimal total = BigDecimal.ZERO;
        List<DetallePedido> detalles = new ArrayList<>();

        for (Map<String, Object> item : items) {
            Integer productoId = Integer.parseInt(item.get("productoId").toString());
            Integer cantidad = Integer.parseInt(item.get("cantidad").toString());

            Optional<Producto> prodOpt = productoRepository.findById(productoId);
            if (prodOpt.isEmpty()) throw new RuntimeException("Producto ID " + productoId + " no encontrado.");

            Producto producto = prodOpt.get();
            if (producto.getStock() < cantidad) {
                throw new RuntimeException("Stock insuficiente para '" + producto.getName() + "'. Disponible: " + producto.getStock());
            }

            producto.setStock(producto.getStock() - cantidad);
            productoRepository.save(producto);

            DetallePedido detalle = new DetallePedido();
            detalle.setPedido(guardado);
            detalle.setProducto(producto);
            detalle.setCantidad(cantidad);
            detalle.setPrecioUnitario(producto.getPrice());

            detalles.add(detallePedidoRepository.save(detalle));
            total = total.add(producto.getPrice().multiply(BigDecimal.valueOf(cantidad)));
        }

        guardado.setTotal(total);
        pedidoRepository.save(guardado);
        guardado.setDetalles(detalles);
        return guardado;
    }

    public List<Pedido> listarPorUsuario(Integer usuarioId) {
        return pedidoRepository.findByUsuarioIdOrderByFechaDesc(usuarioId);
    }

    public List<Pedido> listarTodos() {
        List<Pedido> pedidos = pedidoRepository.findAllByOrderByFechaDesc();
        for (Pedido p : pedidos) {
            p.setDetalles(detallePedidoRepository.findByPedidoId(p.getId()));
        }
        return pedidos;
    }

    public Optional<Pedido> buscarPorId(Integer id) {
        Optional<Pedido> pedido = pedidoRepository.findById(id);
        pedido.ifPresent(p -> p.setDetalles(detallePedidoRepository.findByPedidoId(p.getId())));
        return pedido;
    }

    public Pedido cambiarEstado(Integer pedidoId, String nuevoEstado) {
        Optional<Pedido> pedidoOpt = pedidoRepository.findById(pedidoId);
        if (pedidoOpt.isEmpty()) throw new RuntimeException("Pedido no encontrado.");
        Pedido pedido = pedidoOpt.get();
        pedido.setEstado(nuevoEstado);
        return pedidoRepository.save(pedido);
    }
}
