package neopulse_backend.repository;

import neopulse_backend.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Interfaz que gestiona las operaciones CRUD de la entidad Producto.
 * Hereda las funciones de Spring Data JPA para interactuar con MySQL.
 */
@Repository
public interface ProductoRepository extends JpaRepository<Producto, Integer> {

    /**
     * Busca los productos que pertenecen a una categoría determinada.
     * @param idCategoria Identificador de la categoría.
     * @return Lista de productos de dicha categoría.
     */
    List<Producto> findByCategoriaId(Integer idCategoria);

    List<Producto> findByNameContainingIgnoreCase(String name);

    List<Producto> findByDisponibleTrue();

    List<Producto> findByDisponibleFalse();

    @Query("SELECT p FROM Producto p WHERE LOWER(p.name) LIKE LOWER(CONCAT('%', :query, '%')) AND p.disponible = true")
    List<Producto> buscarDisponiblesPorNombre(@Param("query") String query);

    List<Producto> findByCategoriaIdAndDisponibleTrue(Integer idCategoria);
}
