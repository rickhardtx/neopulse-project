package neopulse_backend.repository;

import neopulse_backend.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Interfaz que gestiona las operaciones CRUD de la entidad Categoria.
 * Hereda las funciones de Spring Data JPA para interactuar con MySQL.
 */
@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {

    /**
     * Busca una categoría por su nombre (se usa en la siembra inicial).
     * @param name Nombre de la categoría.
     * @return Un contenedor Optional que puede incluir la categoría si existe.
     */
    Optional<Categoria> findByName(String name);
}
