package neopulse_backend.repository;

import neopulse_backend.model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Integer> {
    List<Pedido> findByUsuarioIdOrderByFechaDesc(Integer userId);
    List<Pedido> findAllByOrderByFechaDesc();
}
