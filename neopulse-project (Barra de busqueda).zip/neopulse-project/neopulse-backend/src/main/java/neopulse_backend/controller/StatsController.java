package neopulse_backend.controller;

import neopulse_backend.service.ProductoService;
import neopulse_backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/stats")
@CrossOrigin(origins = "*")
public class StatsController {

    @Autowired
    private ProductoService productoService;

    @Autowired
    private UserService userService;

    @GetMapping
    public ResponseEntity<?> obtenerEstadisticas() {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> stats = new HashMap<>();
            stats.put("totalProductos", productoService.contarProductos());
            stats.put("totalCategorias", productoService.contarCategorias());
            stats.put("totalUsuarios", userService.listarUsuarios().size());
            stats.put("productosStockBajo", productoService.productosStockBajo(5).size());
            stats.put("valorInventario", productoService.calcularValorInventario());
            response.put("success", true);
            response.put("stats", stats);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(500).body(response);
        }
    }
}
