package neopulse_backend.controller;

import neopulse_backend.model.Pedido;
import neopulse_backend.service.PedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pedidos")
@CrossOrigin(origins = "*")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @PostMapping
    public ResponseEntity<?> crearPedido(@RequestBody Map<String, Object> body) {
        Map<String, Object> response = new HashMap<>();
        try {
            Integer usuarioId = Integer.parseInt(body.get("usuarioId").toString());
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> items = (List<Map<String, Object>>) body.get("items");
            String direccion = (String) body.getOrDefault("direccion", "");

            if (items == null || items.isEmpty()) {
                response.put("success", false);
                response.put("message", "El pedido debe contener al menos un producto.");
                return ResponseEntity.badRequest().body(response);
            }

            Pedido pedido = pedidoService.crearPedido(usuarioId, items, direccion);
            response.put("success", true);
            response.put("message", "Pedido creado con éxito.");
            response.put("pedido", pedido);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);

        } catch (RuntimeException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    @GetMapping
    public ResponseEntity<?> listarPedidos(@RequestParam(required = false) Integer usuario) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (usuario != null) {
                response.put("pedidos", pedidoService.listarPorUsuario(usuario));
            } else {
                response.put("pedidos", pedidoService.listarTodos());
            }
            response.put("success", true);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(500).body(response);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerPedido(@PathVariable Integer id) {
        Map<String, Object> response = new HashMap<>();
        try {
            var pedido = pedidoService.buscarPorId(id);
            if (pedido.isEmpty()) {
                response.put("success", false);
                response.put("message", "Pedido no encontrado.");
                return ResponseEntity.status(404).body(response);
            }
            response.put("success", true);
            response.put("pedido", pedido.get());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(500).body(response);
        }
    }

    @PutMapping("/{id}/estado")
    public ResponseEntity<?> cambiarEstado(@PathVariable Integer id, @RequestBody Map<String, String> body) {
        Map<String, Object> response = new HashMap<>();
        try {
            String nuevoEstado = body.get("estado");
            if (nuevoEstado == null || nuevoEstado.isBlank()) {
                response.put("success", false);
                response.put("message", "El estado es obligatorio.");
                return ResponseEntity.badRequest().body(response);
            }
            Pedido pedido = pedidoService.cambiarEstado(id, nuevoEstado);
            response.put("success", true);
            response.put("message", "Estado actualizado.");
            response.put("pedido", pedido);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.status(404).body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(500).body(response);
        }
    }
}
