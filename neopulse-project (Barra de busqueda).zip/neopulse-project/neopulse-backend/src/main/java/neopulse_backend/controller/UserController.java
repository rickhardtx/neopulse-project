package neopulse_backend.controller;

import neopulse_backend.model.User;
import neopulse_backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*") 
public class UserController {

    @Autowired
    private UserService userService;

    // ENDPOINT PARA REGISTRO
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();
        try {
            // Se cambia .getCorreo() por .getEmail() debido a la estructura de su modelo
            if (userService.existsByCorreo(user.getEmail())) {
                response.put("success", false);
                response.put("message", "El correo electrónico ya está registrado.");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            userService.saveUser(user);
            response.put("success", true);
            response.put("message", "Usuario registrado con éxito.");
            return ResponseEntity.status(HttpStatus.CREATED).body(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ENDPOINT PARA INICIO DE SESIÓN
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody Map<String, String> loginData) {
        Map<String, Object> response = new HashMap<>();
        String correo = loginData.get("loginCorreo");
        String contrasena = loginData.get("loginContrasena");

        try {
            User user = userService.findByCorreo(correo);
            
            // Se adaptan las llamadas a los métodos generados por Lombok (.getPassword(), .getName(), .getEmail())
            if (user != null && userService.checkPassword(contrasena, user.getPassword())) {
                response.put("success", true);
                response.put("message", "¡Bienvenido de vuelta!");
                
                Map<String, Object> userData = new HashMap<>();
                userData.put("id", user.getId());
                userData.put("nombre", user.getName());
                userData.put("correo", user.getEmail());
                userData.put("rol", user.getRole() != null ? user.getRole() : "cliente");
                response.put("user", userData);
                
                return ResponseEntity.ok(response);
            }

            response.put("success", false);
            response.put("message", "Credenciales incorrectas.");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}