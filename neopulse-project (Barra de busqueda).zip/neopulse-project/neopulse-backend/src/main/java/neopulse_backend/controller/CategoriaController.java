package neopulse_backend.controller;

import neopulse_backend.model.Categoria;
import neopulse_backend.repository.CategoriaRepository;
import neopulse_backend.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/categorias")
@CrossOrigin(origins = "*")
public class CategoriaController {

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @GetMapping
    public ResponseEntity<?> listarCategorias() {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("categorias", categoriaRepository.findAll());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(500).body(response);
        }
    }

    @PostMapping
    public ResponseEntity<?> crearCategoria(@RequestBody Categoria categoria) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (categoria.getName() == null || categoria.getName().isBlank()) {
                response.put("success", false);
                response.put("message", "El nombre de la categoría es obligatorio.");
                return ResponseEntity.badRequest().body(response);
            }
            Categoria guardada = categoriaRepository.save(categoria);
            response.put("success", true);
            response.put("message", "Categoría creada con éxito.");
            response.put("categoria", guardada);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarCategoria(@PathVariable Integer id, @RequestBody Categoria categoria) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (!categoriaRepository.existsById(id)) {
                response.put("success", false);
                response.put("message", "Categoría no encontrada.");
                return ResponseEntity.status(404).body(response);
            }
            Categoria existente = categoriaRepository.findById(id).get();
            existente.setName(categoria.getName());
            existente.setDescription(categoria.getDescription());
            Categoria actualizada = categoriaRepository.save(existente);
            response.put("success", true);
            response.put("message", "Categoría actualizada con éxito.");
            response.put("categoria", actualizada);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(500).body(response);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarCategoria(@PathVariable Integer id) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (!categoriaRepository.existsById(id)) {
                response.put("success", false);
                response.put("message", "Categoría no encontrada.");
                return ResponseEntity.status(404).body(response);
            }
            long productosAsociados = productoRepository.findByCategoriaId(id).size();
            if (productosAsociados > 0) {
                response.put("success", false);
                response.put("message", "No se puede eliminar: hay " + productosAsociados + " producto(s) en esta categoría.");
                return ResponseEntity.status(409).body(response);
            }
            categoriaRepository.deleteById(id);
            response.put("success", true);
            response.put("message", "Categoría eliminada con éxito.");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(500).body(response);
        }
    }
}
