package neopulse_backend.controller;

import neopulse_backend.model.User;
import neopulse_backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

    @Autowired
    private UserService userService;

    @GetMapping
    public ResponseEntity<?> listarUsuarios() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<User> usuarios = userService.listarUsuarios();
            List<Map<String, Object>> usuariosLimpios = usuarios.stream().map(u -> {
                Map<String, Object> data = new HashMap<>();
                data.put("id", u.getId());
                data.put("nombre", u.getName());
                data.put("correo", u.getEmail());
                data.put("telefono", u.getPhone());
                data.put("rol", u.getRole() != null ? u.getRole() : "cliente");
                return data;
            }).toList();
            response.put("success", true);
            response.put("usuarios", usuariosLimpios);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(500).body(response);
        }
    }
}
