// ==========================================================================
// CONFIGURACIÓN Y MANEJO DEL MODAL DE AUTENTICACIÓN
// ==========================================================================

const API_BASE_URL = 'http://localhost:8085/api/auth';

// Elementos del DOM
const authModal = document.getElementById('authModal');
const btnIniciarSesion = document.getElementById('btnIniciarSesion');
const btnCerrarSesion = document.getElementById('btnCerrarSesion');
const userArea = document.getElementById('userArea');
const bienvenidaUsuario = document.getElementById('bienvenidaUsuario');
const closeModal = document.querySelector('.close-modal');

const loginForm = document.getElementById('loginForm');
const registroForm = document.getElementById('registroForm');

// Abre el modal de autenticación (si la página no lo tiene, redirige al index)
function abrirModalAutenticacion() {
    if (authModal) {
        authModal.style.display = 'flex';
    } else {
        window.location.href = 'index.html';
    }
}

// Abrir el modal al presionar "Iniciar sesión"
if (btnIniciarSesion) {
    btnIniciarSesion.addEventListener('click', (e) => {
        e.preventDefault();
        abrirModalAutenticacion();
    });
}

// Cerrar el modal al presionar la "X"
if (closeModal) {
    closeModal.addEventListener('click', () => {
        if (authModal) authModal.style.display = 'none';
    });
}

// Cerrar el modal si se hace clic fuera del recuadro de contenido
window.addEventListener('click', (e) => {
    if (authModal && e.target === authModal) {
        authModal.style.display = 'none';
    }
});

// ==========================================================================
// PROCESAMIENTO DE PETICIONES (FETCH API)
// ==========================================================================

// 1. Envío del Formulario de Registro
if (registroForm) {
    registroForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Captura de datos mapeados exactamente como los espera Jackson en el backend
        const registroData = {
            nombre: document.getElementById('nombre').value,
            correo: document.getElementById('correo').value,
            contrasena: document.getElementById('contrasena').value,
            telefono: document.getElementById('telefono').value
        };

        try {
            const response = await fetch(`${API_BASE_URL}/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(registroData)
            });

            const data = await response.json();

            if (response.ok && data.success) {
                alert(data.message || 'Registro exitoso. Ahora puedes iniciar sesión.');
                registroForm.reset();
            } else {
                alert(`Error: ${data.message || 'No se pudo completar el registro.'}`);
            }

        } catch (error) {
            console.error('Error en la conexión con el servidor:', error);
            alert('Hubo un problema de conexión con el backend de NeoPulse.');
        }
    });
}

// 2. Envío del Formulario de Inicio de Sesión
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Captura de datos para el Map de Spring Boot
        const loginData = {
            loginCorreo: document.getElementById('loginCorreo').value,
            loginContrasena: document.getElementById('loginContrasena').value
        };

        try {
            const response = await fetch(`${API_BASE_URL}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(loginData)
            });

            const data = await response.json();

            if (response.ok && data.success) {
                // Guardar la sesión localmente (persiste entre páginas y recargas)
                localStorage.setItem('neoPulseUser', JSON.stringify(data.user));

                // Cerrar modal y limpiar campos
                if (authModal) authModal.style.display = 'none';
                loginForm.reset();

                // Refrescar navbar: oculta acceso/registro, muestra bienvenida + logout
                actualizarInterfazUsuario();
                notificarUsuario(`${data.message} Bienvenido, ${data.user.nombre}`);
            } else {
                alert(`Error: ${data.message || 'Credenciales inválidas.'}`);
            }

        } catch (error) {
            console.error('Error en la conexión con el servidor:', error);
            alert('Hubo un problema de conexión con el backend de NeoPulse.');
        }
    });
}

// ==========================================================================
// ESTADO DE SESIÓN EN EL NAVBAR (cliente)
// ==========================================================================

// Notificación reutilizable: usa el toast de carrito.js si está disponible
function notificarUsuario(mensaje) {
    if (typeof mostrarNotificacion === 'function') {
        mostrarNotificacion(mensaje);
    } else {
        alert(mensaje);
    }
}

// Lee el usuario guardado de forma segura (null si no hay sesión o hay datos corruptos)
function obtenerUsuarioActual() {
    const guardado = localStorage.getItem('neoPulseUser');
    if (!guardado || guardado === 'undefined') return null;
    try {
        return JSON.parse(guardado);
    } catch (error) {
        return null;
    }
}

// Renderiza el navbar según haya una sesión activa o no
function actualizarInterfazUsuario() {
    const haySesion = obtenerUsuarioActual() !== null;

    // Botón "Iniciar sesión": visible solo sin sesión
    document.querySelectorAll('.auth-buttons').forEach(bloque => {
        bloque.style.display = haySesion ? 'none' : 'flex';
    });

    // Área de usuario (bienvenida + cerrar sesión): visible solo con sesión
    if (userArea) userArea.style.display = haySesion ? 'flex' : 'none';

    if (haySesion && bienvenidaUsuario) {
        const user = obtenerUsuarioActual();
        const primerNombre = (user.nombre || '').split(' ')[0] || 'Usuario';
        bienvenidaUsuario.textContent = `Hola, ${primerNombre}`;
    }

    // Enlace "Admin": visible solo si el usuario tiene rol admin
    const adminLink = document.getElementById('adminLink');
    if (adminLink) {
        const user = obtenerUsuarioActual();
        adminLink.style.display = (user && user.rol === 'admin') ? 'inline-block' : 'none';
    }
}

// Cerrar sesión: limpia el almacenamiento local y restaura el navbar
if (btnCerrarSesion) {
    btnCerrarSesion.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('neoPulseUser');
        actualizarInterfazUsuario();
        notificarUsuario('Has cerrado sesión. ¡Hasta pronto!');
    });
}

// Sincroniza el navbar si se inicia o cierra sesión desde otra pestaña
window.addEventListener('storage', (e) => {
    if (e.key === 'neoPulseUser') actualizarInterfazUsuario();
});

// Ejecutar al cargar la página por si ya hay una sesión activa
document.addEventListener('DOMContentLoaded', actualizarInterfazUsuario);
