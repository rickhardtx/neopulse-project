// ==========================================================================
// PANEL DE ADMINISTRACIÓN — NEO PULSE
// ==========================================================================

const API = 'http://localhost:8085/api';

let usuarioActual = null;

// ==========================================================================
// LOGIN
// ==========================================================================

function initLogin() {
    const stored = localStorage.getItem('neoPulseAdmin');
    if (stored) {
        usuarioActual = JSON.parse(stored);
        mostrarPanel();
        return;
    }

    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value.trim();
        const password = document.getElementById('loginPassword').value;
        const errorDiv = document.getElementById('loginError');

        try {
            const res = await fetch(`${API}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ loginCorreo: email, loginContrasena: password })
            });
            const data = await res.json();
            if (data.success && data.user.rol === 'admin') {
                usuarioActual = data.user;
                localStorage.setItem('neoPulseAdmin', JSON.stringify(usuarioActual));
                mostrarPanel();
            } else if (data.success && data.user.rol !== 'admin') {
                errorDiv.textContent = 'Esta cuenta no tiene permisos de administrador.';
                errorDiv.style.display = 'block';
            } else {
                errorDiv.textContent = data.message || 'Credenciales incorrectas.';
                errorDiv.style.display = 'block';
            }
        } catch (err) {
            errorDiv.textContent = 'No se pudo conectar con el servidor.';
            errorDiv.style.display = 'block';
        }
    });
}

function mostrarPanel() {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('adminPanel').style.display = 'flex';
    document.getElementById('adminName').textContent = usuarioActual.nombre;
    document.getElementById('btnLogout').addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('neoPulseAdmin');
        location.reload();
    });
    initNavigation();
    loadDashboard();
}

// ==========================================================================
// NAVEGACIÓN DEL SIDEBAR
// ==========================================================================

function initNavigation() {
    document.querySelectorAll('.nav-item[data-section]').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.dataset.section;
            document.querySelectorAll('.nav-item[data-section]').forEach(n => n.classList.remove('active'));
            item.classList.add('active');
            document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
            document.getElementById('sectionTitle').textContent = item.textContent.trim();

            if (section === 'dashboard') loadDashboard();
            else if (section === 'productos') loadProductos();
            else if (section === 'categorias') loadCategorias();
            else if (section === 'pedidos') loadPedidos();
        });
    });
}

// ==========================================================================
// DASHBOARD
// ==========================================================================

async function loadDashboard() {
    try {
        const res = await fetch(`${API}/stats`);
        const data = await res.json();
        if (data.success) {
            document.getElementById('statProductos').textContent = data.stats.totalProductos;
            document.getElementById('statCategorias').textContent = data.stats.totalCategorias;
            document.getElementById('statUsuarios').textContent = data.stats.totalUsuarios;
            document.getElementById('statStockBajo').textContent = data.stats.productosStockBajo;
            const valor = Number(data.stats.valorInventario).toLocaleString('es-CO');
            document.getElementById('statInventario').textContent = `$ ${valor}`;
        }
    } catch (err) {
        console.error('Error cargando stats:', err);
    }
}

// ==========================================================================
// CRUD PRODUCTOS
// ==========================================================================

let categoriasCacheAdmin = null;

async function getCategoriasAdmin() {
    if (categoriasCacheAdmin) return categoriasCacheAdmin;
    try {
        const res = await fetch(`${API}/categorias`);
        const data = await res.json();
        if (data.success) categoriasCacheAdmin = data.categorias;
    } catch (err) { console.error(err); }
    return categoriasCacheAdmin || [];
}

async function loadProductos() {
    try {
        const res = await fetch(`${API}/productos`);
        const data = await res.json();
        const tbody = document.getElementById('productosTableBody');
        if (!data.success || !data.productos.length) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-gray);">No hay productos.</td></tr>';
            return;
        }
        tbody.innerHTML = data.productos.map(p => `
            <tr>
                <td>${p.id}</td>
                <td>${p.nombre}</td>
                <td>$ ${Number(p.precio).toLocaleString('es-CO')}</td>
                <td>${p.stock}</td>
                <td>${p.categoria ? p.categoria.nombre : '—'}</td>
                <td class="actions">
                    <button class="btn-sm btn-edit" onclick="editarProducto(${p.id})">Editar</button>
                    <button class="btn-sm btn-delete" onclick="eliminarProducto(${p.id}, '${p.nombre.replace(/'/g, "\\'")}')">Eliminar</button>
                </td>
            </tr>
        `).join('');
    } catch (err) { console.error(err); }
}

document.getElementById('btnNuevoProducto').addEventListener('click', () => abrirModalProducto());

async function abrirModalProducto(producto) {
    const cats = await getCategoriasAdmin();
    const esEdicion = !!producto;
    const html = `
        <div class="form-group">
            <label>Nombre</label>
            <input type="text" id="prodNombre" value="${esEdicion ? producto.nombre : ''}" required>
        </div>
        <div class="form-group">
            <label>Descripción</label>
            <textarea id="prodDesc" rows="3">${esEdicion ? producto.descripcion : ''}</textarea>
        </div>
        <div class="form-group">
            <label>Precio</label>
            <input type="number" id="prodPrecio" value="${esEdicion ? producto.precio : ''}" required>
        </div>
        <div class="form-group">
            <label>Stock</label>
            <input type="number" id="prodStock" value="${esEdicion ? producto.stock : ''}" required>
        </div>
        <div class="form-group">
            <label>Imagen (nombre de archivo)</label>
            <input type="text" id="prodImagen" value="${esEdicion ? (producto.imagen || '') : ''}" placeholder="ej: teclado.png">
        </div>
        <div class="form-group">
            <label>Categoría</label>
            <select id="prodCategoria">
                ${cats.map(c => `<option value="${c.id}" ${esEdicion && producto.categoria && producto.categoria.id === c.id ? 'selected' : ''}>${c.nombre}</option>`).join('')}
            </select>
        </div>
    `;
    abrirModal(esEdicion ? 'Editar Producto' : 'Nuevo Producto', html, async () => {
        const body = {
            nombre: document.getElementById('prodNombre').value,
            descripcion: document.getElementById('prodDesc').value,
            precio: document.getElementById('prodPrecio').value,
            stock: document.getElementById('prodStock').value,
            imagen: document.getElementById('prodImagen').value,
            categoria: { id: document.getElementById('prodCategoria').value }
        };
        const url = esEdicion ? `${API}/productos/${producto.id}` : `${API}/productos`;
        const method = esEdicion ? 'PUT' : 'POST';
        await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
        loadProductos();
    });
}

async function editarProducto(id) {
    try {
        const res = await fetch(`${API}/productos/${id}`);
        const data = await res.json();
        if (data.success) abrirModalProducto(data.producto);
    } catch (err) { console.error(err); }
}

async function eliminarProducto(id, nombre) {
    if (!confirm(`¿Eliminar "${nombre}"?`)) return;
    try {
        await fetch(`${API}/productos/${id}`, { method: 'DELETE' });
        loadProductos();
    } catch (err) { console.error(err); }
}

// ==========================================================================
// CRUD CATEGORÍAS
// ==========================================================================

async function loadCategorias() {
    categoriasCacheAdmin = null;
    const cats = await getCategoriasAdmin();
    const tbody = document.getElementById('categoriasTableBody');
    if (!cats.length) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-gray);">No hay categorías.</td></tr>';
        return;
    }
    tbody.innerHTML = cats.map(c => `
        <tr>
            <td>${c.id}</td>
            <td>${c.nombre}</td>
            <td>${c.descripcion || '—'}</td>
            <td class="actions">
                <button class="btn-sm btn-edit" onclick="editarCategoria(${c.id})">Editar</button>
                <button class="btn-sm btn-delete" onclick="eliminarCategoria(${c.id}, '${c.nombre.replace(/'/g, "\\'")}')">Eliminar</button>
            </td>
        </tr>
    `).join('');
}

document.getElementById('btnNuevaCategoria').addEventListener('click', () => abrirModalCategoria());

async function abrirModalCategoria(categoria) {
    const esEdicion = !!categoria;
    const html = `
        <div class="form-group">
            <label>Nombre</label>
            <input type="text" id="catNombre" value="${esEdicion ? categoria.nombre : ''}" required>
        </div>
        <div class="form-group">
            <label>Descripción</label>
            <textarea id="catDesc" rows="3">${esEdicion ? (categoria.descripcion || '') : ''}</textarea>
        </div>
    `;
    abrirModal(esEdicion ? 'Editar Categoría' : 'Nueva Categoría', html, async () => {
        const body = {
            nombre: document.getElementById('catNombre').value,
            descripcion: document.getElementById('catDesc').value
        };
        const url = esEdicion ? `${API}/categorias/${categoria.id}` : `${API}/categorias`;
        const method = esEdicion ? 'PUT' : 'POST';
        await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
        categoriasCacheAdmin = null;
        loadCategorias();
    });
}

async function editarCategoria(id) {
    const cats = await getCategoriasAdmin();
    const cat = cats.find(c => c.id === id);
    if (cat) abrirModalCategoria(cat);
}

async function eliminarCategoria(id, nombre) {
    try {
        const res = await fetch(`${API}/categorias/${id}`, { method: 'DELETE' });
        const data = await res.json();
        if (!data.success) {
            alert(data.message);
            return;
        }
        categoriasCacheAdmin = null;
        loadCategorias();
    } catch (err) { console.error(err); }
}

// ==========================================================================
// MODAL GENÉRICO
// ==========================================================================

function abrirModal(titulo, bodyHtml, onSave) {
    document.getElementById('modalTitle').textContent = titulo;
    document.getElementById('modalBody').innerHTML = bodyHtml;
    document.getElementById('modalOverlay').style.display = 'flex';

    const saveBtn = document.getElementById('modalSave');
    const newSave = saveBtn.cloneNode(true);
    saveBtn.parentNode.replaceChild(newSave, saveBtn);
    newSave.id = 'modalSave';
    newSave.addEventListener('click', async () => {
        await onSave();
        cerrarModal();
    });

    document.getElementById('modalClose').onclick = cerrarModal;
    document.getElementById('modalCancel').onclick = cerrarModal;
}

function cerrarModal() {
    document.getElementById('modalOverlay').style.display = 'none';
}

// ==========================================================================
// PEDIDOS
// ==========================================================================

async function loadPedidos() {
    try {
        const res = await fetch(`${API}/pedidos`);
        const data = await res.json();
        const tbody = document.getElementById('pedidosTableBody');
        if (!data.success || !data.pedidos.length) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-gray);">No hay pedidos.</td></tr>';
            return;
        }
        tbody.innerHTML = data.pedidos.map(p => {
            const usuarioNombre = p.usuario ? p.usuario.nombre : '—';
            return `
                <tr>
                    <td>${p.id}</td>
                    <td>${p.fecha}</td>
                    <td>${usuarioNombre}</td>
                    <td>$ ${Number(p.total).toLocaleString('es-CO')}</td>
                    <td><span class="badge-estado badge-${p.estado.toLowerCase()}">${p.estado}</span></td>
                    <td class="actions">
                        <button class="btn-sm btn-edit" onclick="verPedido(${p.id})">Detalle</button>
                        <button class="btn-sm btn-edit" onclick="cambiarEstadoPedido(${p.id}, '${p.estado}')">Estado</button>
                    </td>
                </tr>`;
        }).join('');
    } catch (err) {
        console.error('Error cargando pedidos:', err);
    }
}

async function verPedido(id) {
    try {
        const res = await fetch(`${API}/pedidos/${id}`);
        const data = await res.json();
        if (!data.success) return;
        const p = data.pedido;
        const items = (p.detalles || []).map(d => `
            <tr>
                <td>${d.producto ? d.producto.nombre : '—'}</td>
                <td>${d.cantidad}</td>
                <td>$ ${Number(d.precioUnitario).toLocaleString('es-CO')}</td>
                <td>$ ${Number(d.cantidad * d.precioUnitario).toLocaleString('es-CO')}</td>
            </tr>
        `).join('');
        const html = `
            <p><strong>Pedido #${p.id}</strong> — ${p.fecha} — Estado: ${p.estado}</p>
            <p><strong>Usuario:</strong> ${p.usuario ? p.usuario.nombre + ' (' + p.usuario.correo + ')' : '—'}</p>
            <table class="data-table" style="margin-top:12px;">
                <thead><tr><th>Producto</th><th>Cantidad</th><th>Precio Unit.</th><th>Subtotal</th></tr></thead>
                <tbody>${items}</tbody>
            </table>
            <p style="margin-top:12px;"><strong>Total: $ ${Number(p.total).toLocaleString('es-CO')}</strong></p>
        `;
        abrirModal('Detalle del Pedido #' + p.id, html, () => cerrarModal());
    } catch (err) {
        console.error(err);
    }
}

async function cambiarEstadoPedido(id, estadoActual) {
    const html = `
        <div class="form-group">
            <label>Estado actual: <strong>${estadoActual}</strong></label>
            <select id="nuevoEstado">
                <option value="Pendiente" ${estadoActual === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
                <option value="Enviado" ${estadoActual === 'Enviado' ? 'selected' : ''}>Enviado</option>
                <option value="Entregado" ${estadoActual === 'Entregado' ? 'selected' : ''}>Entregado</option>
            </select>
        </div>
    `;
    abrirModal('Cambiar Estado del Pedido #' + id, html, async () => {
        const nuevoEstado = document.getElementById('nuevoEstado').value;
        await fetch(`${API}/pedidos/${id}/estado`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ estado: nuevoEstado })
        });
        loadPedidos();
    });
}

// ==========================================================================
// INIT
// ==========================================================================

document.addEventListener('DOMContentLoaded', initLogin);
