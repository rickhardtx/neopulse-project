// ==========================================================================
// VITRINA DINÁMICA: ÍNDICE (Promociones / Próximamente / Categorías)
// ==========================================================================

const API_PRODUCTOS_URL = 'http://localhost:8085/api/productos';
const API_CATEGORIAS_URL = 'http://localhost:8085/api/categorias';

// Lista por defecto usada como respaldo si el backend no responde
const CATEGORIAS_POR_DEFECTO = [
    { id: 1, nombre: 'Teclados' },
    { id: 2, nombre: 'Mouses' },
    { id: 3, nombre: 'Mousepads' },
    { id: 4, nombre: 'Audífonos y Cornetas' },
    { id: 5, nombre: 'Monitores' },
    { id: 6, nombre: 'Accesorios' }
];

// Productos con promoción activa: precio original vs precio actual con descuento
const PROMOCIONES = {
    1: { precioOriginal: 120000 }, // Teclado mecanico K-MK200
    2: { precioOriginal: 95000 },  // Mouse alambrico M-ECG500
    5: { precioOriginal: 80000 }   // Audifonos Alambricos G-HP100
};

// Productos que aparecen en la pestaña "Próximamente" (sin precio ni carrito)
const PRODUCTOS_PROXIMOS = [3, 4]; // Mousepad RGB NeoPulse XXL, Cornetas Gaming CP-X9

let productosCache = null;
let categoriasCache = null;

async function obtenerProductos(query, disponible) {
    const esVistaVenta = disponible === undefined || disponible === true;
    if (esVistaVenta && !query && productosCache) return productosCache;
    try {
        let url = API_PRODUCTOS_URL;
        const params = [];
        if (query) params.push(`query=${encodeURIComponent(query)}`);
        if (disponible !== undefined) params.push(`disponible=${disponible}`);
        if (params.length) url += '?' + params.join('&');
        const response = await fetch(url);
        const data = await response.json();
        if (response.ok && data.success && Array.isArray(data.productos)) {
            if (esVistaVenta && !query) productosCache = data.productos;
            return data.productos;
        }
    } catch (error) {
        console.error('No se pudo conectar con el backend de productos:', error);
    }
    return [];
}

async function obtenerCategorias() {
    if (categoriasCache) return categoriasCache;
    let categorias = CATEGORIAS_POR_DEFECTO;
    try {
        const response = await fetch(API_CATEGORIAS_URL);
        const data = await response.json();
        if (response.ok && data.success && data.categorias && data.categorias.length > 0) {
            categorias = data.categorias;
        }
    } catch (error) {
        console.error('No se pudieron cargar las categorías; se usa la lista por defecto:', error);
    }
    categoriasCache = categorias;
    return categoriasCache;
}

// Formatea un número como moneda al estilo colombiano: $ 100.000
function formatearPrecio(precio) {
    return `$ ${Number(precio).toLocaleString('es-CO')}`;
}

// Pinta el HTML en la grilla. Si mantenerSiVacio está activo y no hay tarjetas,
// conserva el contenido estático del HTML (fallback cuando el backend no responde).
function renderizarGrid(html, mantenerSiVacio) {
    const grid = document.getElementById('productGrid');
    if (!grid) return;
    if (mantenerSiVacio && html.length === 0 && grid.querySelector('.product-card')) return;
    grid.innerHTML = html.length
        ? html.join('')
        : '<div class="grid-empty"><p>No hay productos disponibles por el momento.</p></div>';
}

// ==========================================================================
// TARJETAS
// ==========================================================================

function crearTarjetaProducto(producto) {
    const imagen = producto.imagen ? `imagenes/${producto.imagen}` : 'imagenes/logo.png';
    const promo = PROMOCIONES[producto.id];
    const precioOriginal = promo
        ? `<span class="old-price">${formatearPrecio(promo.precioOriginal)}</span>`
        : '';
    return `
        <div class="product-card">
            <img src="${imagen}" alt="${producto.nombre}" class="p-img">
            <h3>${producto.nombre}</h3>
            <div class="prices">
                <span class="current-price">${formatearPrecio(producto.precio)}</span>
                ${precioOriginal}
            </div>
            <button class="add-cart"
                data-id="${producto.id}"
                data-nombre="${producto.nombre}"
                data-precio="${producto.precio}"
                data-imagen="${producto.imagen || ''}"
                data-stock="${producto.stock || 99}">Añadir al carrito</button>
        </div>`;
}

function crearTarjetaProximo(producto) {
    const imagen = producto.imagen ? `imagenes/${producto.imagen}` : 'imagenes/logo.png';
    return `
        <div class="product-card proximo-card">
            <div class="proximo-img-wrap">
                <img src="${imagen}" alt="${producto.nombre}" class="p-img">
            </div>
            <div class="product-title-clean">${producto.nombre}</div>
        </div>`;
}

function crearTarjetaCategoria(cat) {
    return `
        <div class="category-card" data-categoria="${cat.id}">
            <h3>${cat.nombre}</h3>
            <p>${cat.descripcion || 'Explora los productos de esta categoría.'}</p>
            <span class="cat-link">Ver productos &rarr;</span>
        </div>`;
}

// ==========================================================================
// VISTAS DEL ÍNDICE
// ==========================================================================

async function renderTabPromociones() {
    const productos = await obtenerProductos(null, true);
    const promociones = productos.filter(p => PROMOCIONES[p.id]);
    renderizarGrid(promociones.map(crearTarjetaProducto), true);
}

async function renderTabProximamente() {
    let proximos = await obtenerProductos(null, false);
    if (!proximos.length) {
        const todos = await obtenerProductos(null, true);
        proximos = todos.filter(p => PRODUCTOS_PROXIMOS.indexOf(p.id) !== -1);
    }
    renderizarGrid(proximos.map(crearTarjetaProximo), true);
}

async function renderTabCategorias() {
    const categorias = await obtenerCategorias();
    renderizarGrid(categorias.map(crearTarjetaCategoria), true);
}

async function renderCatalogoCompleto() {
    const productos = await obtenerProductos(null, true);
    renderizarGrid(productos.map(crearTarjetaProducto), true);
}

async function renderProductosCategoria(id) {
    const categorias = await obtenerCategorias();
    const cat = categorias.find(c => String(c.id) === String(id)) || { nombre: 'Categoría' };
    const productos = (await obtenerProductos(null, true)).filter(
        p => p.categoria && String(p.categoria.id) === String(id)
    );
    const cards = productos.map(crearTarjetaProducto);
    const contenido = [
        `<div class="category-results">
            <a href="#" class="back-categories">&larr; Todas las categorías</a>
            <h3 class="category-title">${cat.nombre}</h3>
        </div>`
    ].concat(cards.length ? cards : ['<div class="grid-empty"><p>No hay productos en esta categoría.</p></div>']);
    renderizarGrid(contenido);
}

// ==========================================================================
// CONTROL DE VISTAS (pestañas + transición)
// ==========================================================================

function setTabActivo(tab) {
    document.querySelectorAll('.section-tabs .tab').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tab);
    });
}

// Alterna la vista con una transición suave (fade + desplazamiento)
function cambiarVista(renderFn) {
    const grid = document.getElementById('productGrid');
    if (!grid) return;
    grid.classList.add('view-switch');
    setTimeout(async () => {
        await renderFn();
        grid.classList.remove('view-switch');
    }, 220);
}

function cambiarTab(tab) {
    setTabActivo(tab);
    if (tab === 'promociones') cambiarVista(renderTabPromociones);
    else if (tab === 'proximamente') cambiarVista(renderTabProximamente);
    else if (tab === 'categorias') cambiarVista(renderTabCategorias);
}

// Carga productos desde el servidor (con búsqueda por nombre opcional)
async function cargarProductos(query) {
    cambiarVista(async () => {
        setTabActivo(null);
        const productos = await obtenerProductos(query, true);
        renderizarGrid(productos.map(crearTarjetaProducto), true);
    });
}

// ==========================================================================
// MENÚ DESPLEGABLE DE CATEGORÍAS (navbar)
// ==========================================================================

async function poblarMenuCategorias() {
    const menu = document.getElementById('menuCategorias');
    if (!menu) return;
    const categorias = await obtenerCategorias();
    menu.innerHTML = categorias
        .map(c => `<li><a href="#productGrid" data-categoria="${c.id}">${c.nombre}</a></li>`)
        .join('');
}

// ==========================================================================
// INICIALIZACIÓN
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
    // Pestañas del índice: alternan la vista de la vitrina
    document.querySelectorAll('.section-tabs .tab').forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.tab;
            if (!tab) return;
            cambiarTab(tab);
            document.getElementById('productGrid').scrollIntoView({ behavior: 'smooth' });
        });
    });

    // Navbar: "Promociones" y "Llegando" controlan las pestañas
    const btnNavPromociones = document.getElementById('btnNavPromociones');
    if (btnNavPromociones) {
        btnNavPromociones.addEventListener('click', (e) => {
            e.preventDefault();
            cambiarTab('promociones');
            document.getElementById('productGrid').scrollIntoView({ behavior: 'smooth' });
        });
    }
    const btnNavLlegando = document.getElementById('btnNavLlegando');
    if (btnNavLlegando) {
        btnNavLlegando.addEventListener('click', (e) => {
            e.preventDefault();
            cambiarTab('proximamente');
            document.getElementById('productGrid').scrollIntoView({ behavior: 'smooth' });
        });
    }

    // Dropdown "Categorías": abrir/cerrar al hacer clic en el toggler
    const btnCategorias = document.getElementById('btnCategorias');
    const dropdown = btnCategorias ? btnCategorias.closest('.dropdown') : null;
    if (btnCategorias) {
        btnCategorias.addEventListener('click', (e) => {
            e.preventDefault();
            if (dropdown) dropdown.classList.toggle('open');
        });
    }

    // Cierra el dropdown al hacer clic fuera de él
    document.addEventListener('click', (e) => {
        if (dropdown && !dropdown.contains(e.target)) {
            dropdown.classList.remove('open');
        }
    });

    poblarMenuCategorias();

    // Búsqueda predictiva en tiempo real (dropdown flotante debajo del input)
    const searchInput = document.getElementById('searchInput');
    const searchDropdown = document.getElementById('searchDropdown');
    if (searchInput && searchDropdown) {
        const ocultarDropdown = () => searchDropdown.classList.remove('active');
        const mostrarDropdown = () => searchDropdown.classList.add('active');

        const renderizarDropdown = (productos) => {
            if (!productos.length) {
                searchDropdown.innerHTML = '<div class="search-empty">Sin resultados</div>';
                return;
            }
            searchDropdown.innerHTML = productos.map(p => {
                const imagen = p.imagen ? `imagenes/${p.imagen}` : 'imagenes/logo.png';
                return `
                    <div class="search-item"
                         data-id="${p.id}"
                         data-nombre="${p.nombre}"
                         data-precio="${p.precio}"
                         data-imagen="${p.imagen || ''}"
                         data-stock="${p.stock || 99}">
                        <img src="${imagen}" alt="${p.nombre}" class="search-item-img">
                        <div class="search-item-info">
                            <span class="search-item-name">${p.nombre}</span>
                            <span class="search-item-price">${formatearPrecio(p.precio)}</span>
                        </div>
                    </div>`;
            }).join('');
        };

        searchDropdown.addEventListener('click', (e) => {
            const item = e.target.closest('.search-item');
            if (!item) return;
            const producto = {
                id: item.dataset.id,
                nombre: item.dataset.nombre,
                precio: Number(item.dataset.precio),
                imagen: item.dataset.imagen,
                stock: Number(item.dataset.stock)
            };
            agregarAlCarrito(producto);
            mostrarNotificacion(`${producto.nombre} añadido al carrito`);
            ocultarDropdown();
        });

        let debounceTimer;
        searchInput.addEventListener('input', () => {
            clearTimeout(debounceTimer);
            const query = searchInput.value.trim();
            if (!query) { ocultarDropdown(); return; }
            debounceTimer = setTimeout(async () => {
                let productos = [];
                try {
                    const res = await fetch(`${API_PRODUCTOS_URL}/buscar?query=${encodeURIComponent(query)}`);
                    if (res.ok) {
                        const data = await res.json();
                        if (data.success && Array.isArray(data.productos)) {
                            productos = data.productos;
                        }
                    }
                } catch (err) {
                    console.error('Búsqueda remota falló, se usa el catálogo local:', err);
                }
                // Refuerzo local: si el backend no responde, filtra el catálogo en caché
                if (!productos.length) {
                    if (!productosCache) await obtenerProductos(null, true);
                    const q = query.toLowerCase();
                    productos = (productosCache || []).filter(p =>
                        p.disponible !== false &&
                        p.nombre && p.nombre.toLowerCase().includes(q)
                    );
                }
                renderizarDropdown(productos.filter(p => p.disponible !== false));
                mostrarDropdown();
            }, 300);
        });

        searchInput.addEventListener('blur', () => setTimeout(ocultarDropdown, 150));
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.search-bar')) ocultarDropdown();
        });
    }

    // Delegación de clics dentro de la grilla
    const grid = document.getElementById('productGrid');
    if (grid) {
        grid.addEventListener('click', (e) => {
            const addBtn = e.target.closest('.add-cart');
            if (addBtn) {
                const producto = {
                    id: addBtn.dataset.id,
                    nombre: addBtn.dataset.nombre,
                    precio: Number(addBtn.dataset.precio),
                    imagen: addBtn.dataset.imagen,
                    stock: Number(addBtn.dataset.stock)
                };
                agregarAlCarrito(producto);
                mostrarNotificacion(`${producto.nombre} añadido al carrito`);
                return;
            }

            const catCard = e.target.closest('.category-card');
            if (catCard) {
                cambiarVista(() => renderProductosCategoria(catCard.dataset.categoria));
                return;
            }

            const backBtn = e.target.closest('.back-categories');
            if (backBtn) {
                e.preventDefault();
                cambiarTab('categorias');
                return;
            }
        });
    }

    // Vista inicial: filtro pendiente de otra página o todos los productos
    const filtro = sessionStorage.getItem('neoPulseFiltroCategoria');
    if (filtro && filtro !== 'all') {
        setTabActivo('categorias');
        renderProductosCategoria(filtro);
    } else {
        cargarProductos();
    }
});
