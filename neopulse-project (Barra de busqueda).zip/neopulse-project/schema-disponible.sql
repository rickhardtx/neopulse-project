-- ==========================================================================
-- schema-disponible.sql
-- Agrega el campo "disponible" a la tabla producto para distinguir los
-- productos a la venta de los de la sección "Próximamente" / "Próximos a
-- llegar". Compatible con el backend NeoPulse (entidad Producto.disponible).
-- Ejecutar en la base de datos tienda_neopulse (MySQL/MariaDB de XAMPP).
-- ==========================================================================

-- 1) Nueva columna: 1 = a la venta, 0 = próximamente (default 1 = en venta)
ALTER TABLE producto
    ADD COLUMN disponible TINYINT(1) NOT NULL DEFAULT 1;

-- 2) Marcar como "Próximamente" los productos que hoy aparecen en esa sección
--    (Mousepad RGB NeoPulse XXL y Cornetas Gaming CP-X9, id_producto 3 y 4).
--    Ajusta los IDs si tu catálogo difiere.
UPDATE producto SET disponible = 0 WHERE id_producto IN (3, 4);
