-- ==========================================================================
-- schema-pedidos.sql
-- Tablas para el módulo de pedidos de NeoPulse.
-- DDL compatible con "Base de datos XAMP.txt": mismas columnas, tipos y
-- restricciones de clave foránea. Los nombres de tabla se mantienen en
-- minúsculas (pedido, detalle_pedido) para coincidir exactamente con las
-- entidades JPA del backend (@Table name = "pedido" / "detalle_pedido").
-- Ejecutar en la base de datos tienda_neopulse (MySQL/MariaDB de XAMPP).
-- ==========================================================================

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS detalle_pedido;
DROP TABLE IF EXISTS pedido;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE pedido (
    id_pedido   INT AUTO_INCREMENT PRIMARY KEY,
    fecha       DATE NOT NULL,
    estado      VARCHAR(30) NOT NULL,
    total       DECIMAL(10, 2) NOT NULL,
    id_usuario  INT,
    CONSTRAINT Pedido_Usuario_FK FOREIGN KEY (id_usuario)
        REFERENCES usuario (id_usuario)
);

CREATE TABLE detalle_pedido (
    id_detalle_pedido  INT AUTO_INCREMENT PRIMARY KEY,
    cantidad           INT NOT NULL,
    precio_unitario    DECIMAL(10, 2) NOT NULL,
    id_pedido          INT,
    id_producto        INT,
    CONSTRAINT Det_Ped_Ped_FK FOREIGN KEY (id_pedido)
        REFERENCES pedido (id_pedido),
    CONSTRAINT Det_Ped_Prod_FK FOREIGN KEY (id_producto)
        REFERENCES producto (id_producto)
);
