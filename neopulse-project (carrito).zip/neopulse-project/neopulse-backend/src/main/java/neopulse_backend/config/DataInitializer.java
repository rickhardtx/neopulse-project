package neopulse_backend.config;

import neopulse_backend.model.Categoria;
import neopulse_backend.model.Producto;
import neopulse_backend.repository.CategoriaRepository;
import neopulse_backend.repository.ProductoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Siembra las categorías y productos iniciales de NeoPulse al levantar el backend.
 * Solo actúa cuando la tabla de productos está vacía, por lo que es idempotente.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Override
    public void run(String... args) {
        if (productoRepository.count() > 0) {
            log.info("La base de datos ya contiene productos; se omite la siembra inicial.");
            return;
        }

        log.info("Sembrando categorías y productos iniciales de NeoPulse...");

        Categoria perifericos = buscarOCrearCategoria("Periféricos",
                "Teclados, mouses y accesorios de entrada para tu setup.");
        Categoria audio = buscarOCrearCategoria("Audio",
                "Audífonos y sonido para tu experiencia gaming.");

        crearProducto("Teclado mecanico K-MK200",
                "Teclado mecánico con retroiluminación RGB, ideal para gaming.",
                new BigDecimal("100000"), 25, "teclado.png", perifericos);
        crearProducto("Mouse alambrico M-ECG500",
                "Mouse gaming con sensor de alta precisión y diseño ergonómico.",
                new BigDecimal("72000"), 30, "mouse.png", perifericos);
        crearProducto("Audifonos Alambricos G-HP100",
                "Audífonos over-ear con sonido envolvente y micrófono integrado.",
                new BigDecimal("65000"), 20, "audifonos.png", audio);

        log.info("Siembra inicial de catálogo completada.");
    }

    // Reutiliza la categoría si ya existe, de lo contrario la crea
    private Categoria buscarOCrearCategoria(String nombre, String descripcion) {
        return categoriaRepository.findByName(nombre).orElseGet(() -> {
            Categoria categoria = new Categoria();
            categoria.setName(nombre);
            categoria.setDescription(descripcion);
            return categoriaRepository.save(categoria);
        });
    }

    private void crearProducto(String nombre, String descripcion, BigDecimal precio, Integer stock,
                               String imagen, Categoria categoria) {
        Producto producto = new Producto();
        producto.setName(nombre);
        producto.setDescription(descripcion);
        producto.setPrice(precio);
        producto.setStock(stock);
        producto.setImage(imagen);
        producto.setCategoria(categoria);
        productoRepository.save(producto);
    }
}
