package neopulse_backend.service;

import neopulse_backend.model.Categoria;
import neopulse_backend.model.Producto;
import neopulse_backend.repository.CategoriaRepository;
import neopulse_backend.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    // Devuelve todos los productos del catálogo
    public List<Producto> listarProductos() {
        return productoRepository.findAll();
    }

    // Devuelve los productos de una categoría específica
    public List<Producto> listarPorCategoria(Integer idCategoria) {
        return productoRepository.findByCategoriaId(idCategoria);
    }

    // Busca un producto por su identificador
    public Optional<Producto> buscarPorId(Integer idProducto) {
        return productoRepository.findById(idProducto);
    }

    // Valida que la categoría indicada exista antes de asociarla al producto
    public boolean existeCategoria(Integer idCategoria) {
        return categoriaRepository.existsById(idCategoria);
    }

    // Registra un producto nuevo en el catálogo
    public Producto guardarProducto(Producto producto) {
        return productoRepository.save(producto);
    }

    // Actualiza los datos de un producto existente
    public Producto actualizarProducto(Producto producto) {
        return productoRepository.save(producto);
    }

    // Elimina un producto del catálogo por su identificador
    public void eliminarProducto(Integer idProducto) {
        productoRepository.deleteById(idProducto);
    }

    // Devuelve todas las categorías disponibles
    public List<Categoria> listarCategorias() {
        return categoriaRepository.findAll();
    }
}
