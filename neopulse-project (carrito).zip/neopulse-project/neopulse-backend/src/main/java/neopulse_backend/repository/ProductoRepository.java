package neopulse_backend.repository;

import neopulse_backend.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Interfaz que gestiona las operaciones CRUD de la entidad Producto.
 * Hereda las funciones de Spring Data JPA para interactuar con MySQL.
 */
@Repository
public interface ProductoRepository extends JpaRepository<Producto, Integer> {

    /**
     * Busca los productos que pertenecen a una categoría determinada.
     * @param idCategoria Identificador de la categoría.
     * @return Lista de productos de dicha categoría.
     */
    List<Producto> findByCategoriaId(Integer idCategoria);
}
