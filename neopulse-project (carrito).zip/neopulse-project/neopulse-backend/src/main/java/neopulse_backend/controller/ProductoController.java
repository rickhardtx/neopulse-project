package neopulse_backend.controller;

import neopulse_backend.model.Producto;
import neopulse_backend.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    // ENDPOINT PARA LISTAR PRODUCTOS (con filtro opcional por categoría)
    @GetMapping("/productos")
    public ResponseEntity<?> listarProductos(@RequestParam(required = false) Integer categoria) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (categoria != null) {
                if (!productoService.existeCategoria(categoria)) {
                    response.put("success", false);
                    response.put("message", "La categoría especificada no existe.");
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
                }
                response.put("productos", productoService.listarPorCategoria(categoria));
            } else {
                response.put("productos", productoService.listarProductos());
            }
            response.put("success", true);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ENDPOINT PARA OBTENER UN PRODUCTO POR SU IDENTIFICADOR
    @GetMapping("/productos/{id}")
    public ResponseEntity<?> obtenerProducto(@PathVariable Integer id) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<Producto> producto = productoService.buscarPorId(id);
            if (producto.isEmpty()) {
                response.put("success", false);
                response.put("message", "Producto no encontrado.");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
            response.put("success", true);
            response.put("producto", producto.get());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ENDPOINT PARA CREAR UN PRODUCTO NUEVO
    @PostMapping("/productos")
    public ResponseEntity<?> crearProducto(@RequestBody Producto producto) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (producto.getName() == null || producto.getName().isBlank()
                    || producto.getPrice() == null || producto.getStock() == null) {
                response.put("success", false);
                response.put("message", "Los campos nombre, precio y stock son obligatorios.");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            Producto guardado = productoService.guardarProducto(producto);
            response.put("success", true);
            response.put("message", "Producto creado con éxito.");
            response.put("producto", guardado);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ENDPOINT PARA ACTUALIZAR UN PRODUCTO EXISTENTE
    @PutMapping("/productos/{id}")
    public ResponseEntity<?> actualizarProducto(@PathVariable Integer id, @RequestBody Producto producto) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<Producto> existente = productoService.buscarPorId(id);
            if (existente.isEmpty()) {
                response.put("success", false);
                response.put("message", "Producto no encontrado.");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            Producto actual = existente.get();
            actual.setName(producto.getName());
            actual.setDescription(producto.getDescription());
            actual.setPrice(producto.getPrice());
            actual.setStock(producto.getStock());
            actual.setImage(producto.getImage());
            actual.setCategoria(producto.getCategoria());

            Producto actualizado = productoService.actualizarProducto(actual);
            response.put("success", true);
            response.put("message", "Producto actualizado con éxito.");
            response.put("producto", actualizado);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ENDPOINT PARA ELIMINAR UN PRODUCTO
    @DeleteMapping("/productos/{id}")
    public ResponseEntity<?> eliminarProducto(@PathVariable Integer id) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<Producto> existente = productoService.buscarPorId(id);
            if (existente.isEmpty()) {
                response.put("success", false);
                response.put("message", "Producto no encontrado.");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            productoService.eliminarProducto(id);
            response.put("success", true);
            response.put("message", "Producto eliminado con éxito.");
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ENDPOINT PARA LISTAR LAS CATEGORÍAS DISPONIBLES
    @GetMapping("/categorias")
    public ResponseEntity<?> listarCategorias() {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("categorias", productoService.listarCategorias());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
