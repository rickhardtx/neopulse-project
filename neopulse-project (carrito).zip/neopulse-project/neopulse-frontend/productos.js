// ==========================================================================
// CARGA DINÁMICA DEL CATÁLOGO DE PRODUCTOS DESDE LA API
// ==========================================================================

const API_PRODUCTOS_URL = 'http://localhost:8085/api/productos';

// Carga los productos del backend y los pinta en la grilla del catálogo
async function cargarProductos() {
    try {
        const response = await fetch(API_PRODUCTOS_URL);
        const data = await response.json();

        if (response.ok && data.success && data.productos && data.productos.length > 0) {
            renderizarProductos(data.productos);
        }
    } catch (error) {
        // Si el backend no responde se conservan las tarjetas estáticas del HTML
        console.error('No se pudo conectar con el backend de productos:', error);
    }
}

// Construye las tarjetas respetando la estructura visual original de NeoPulse:
// .product-card > img.p-img + h3 + .prices(.current-price) + button.add-cart
function renderizarProductos(productos) {
    const grid = document.getElementById('productGrid');
    if (!grid) return;

    grid.innerHTML = '';

    productos.forEach(producto => {
        const card = document.createElement('div');
        card.className = 'product-card';

        const imagen = producto.imagen ? `imagenes/${producto.imagen}` : 'imagenes/logo.png';

        card.innerHTML = `
            <img src="${imagen}" alt="${producto.nombre}" class="p-img">
            <h3>${producto.nombre}</h3>
            <div class="prices">
                <span class="current-price">${formatearPrecio(producto.precio)}</span>
            </div>
            <button class="add-cart"
                data-id="${producto.id}"
                data-nombre="${producto.nombre}"
                data-precio="${producto.precio}"
                data-imagen="${producto.imagen || ''}"
                data-stock="${producto.stock || 99}">Añadir al carrito</button>
        `;

        grid.appendChild(card);
    });
}

// Formatea un número como moneda al estilo colombiano: $ 100.000
function formatearPrecio(precio) {
    return `$ ${Number(precio).toLocaleString('es-CO')}`;
}

// Inicializa el catálogo y conecta los botones "Añadir al carrito"
document.addEventListener('DOMContentLoaded', () => {
    cargarProductos();

    const grid = document.getElementById('productGrid');
    if (grid) {
        grid.addEventListener('click', (e) => {
            const btn = e.target.closest('.add-cart');
            if (!btn) return;

            const producto = {
                id: btn.dataset.id,
                nombre: btn.dataset.nombre,
                precio: Number(btn.dataset.precio),
                imagen: btn.dataset.imagen,
                stock: Number(btn.dataset.stock)
            };

            agregarAlCarrito(producto);
            mostrarNotificacion(`${producto.nombre} añadido al carrito`);
        });
    }
});
