// ==========================================================================
// LÓGICA COMPARTIDA DEL CARRITO (localStorage + contador + notificaciones)
// ==========================================================================

const CART_KEY = 'neoPulseCart';

// Lee el carrito guardado en el navegador (array de items)
function obtenerCarrito() {
    return JSON.parse(localStorage.getItem(CART_KEY) || '[]');
}

// Persiste el carrito y refresca el contador del header
function guardarCarrito(carrito) {
    localStorage.setItem(CART_KEY, JSON.stringify(carrito));
    actualizarContadorCarrito();
}

// Suma las cantidades de todos los items
function totalItems() {
    return obtenerCarrito().reduce((total, item) => total + item.cantidad, 0);
}

// Añade un producto al carrito (o incrementa su cantidad si ya existe)
function agregarAlCarrito(producto) {
    const carrito = obtenerCarrito();
    const existente = carrito.find(item => String(item.id) === String(producto.id));

    if (existente) {
        if (existente.cantidad < (producto.stock || 99)) {
            existente.cantidad += 1;
        }
    } else {
        carrito.push({
            id: producto.id,
            nombre: producto.nombre,
            precio: producto.precio,
            imagen: producto.imagen,
            stock: producto.stock || 99,
            cantidad: 1
        });
    }

    guardarCarrito(carrito);
}

// Refresca el badge numérico del enlace "Carrito" del header
function actualizarContadorCarrito() {
    const badge = document.getElementById('cartCount');
    if (badge) {
        badge.textContent = totalItems();
    }
}

// Formatea un número como moneda al estilo colombiano: $ 100.000
function formatearPrecio(precio) {
    return `$ ${Number(precio).toLocaleString('es-CO')}`;
}

// Muestra una notificación rápida tipo toast en la parte inferior
function mostrarNotificacion(mensaje) {
    let toast = document.getElementById('cartToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'cartToast';
        toast.className = 'cart-toast';
        document.body.appendChild(toast);
    }
    toast.textContent = mensaje;
    toast.classList.add('show');

    clearTimeout(mostrarNotificacion._timer);
    mostrarNotificacion._timer = setTimeout(() => toast.classList.remove('show'), 2200);
}

// Al cargar cualquier página, sincroniza el contador con el estado guardado
document.addEventListener('DOMContentLoaded', actualizarContadorCarrito);

// ==========================================================================
// PÁGINA CARRITO.HTML (render de items, cantidades, total y checkout)
// ==========================================================================
const cartItemsEl = document.getElementById('cartItems');
if (cartItemsEl) {
    initPaginaCarrito();
}

function initPaginaCarrito() {
    const cartTotalEl = document.getElementById('cartTotal');
    const cartTotalFinalEl = document.getElementById('cartTotalFinal');
    const cartVacioEl = document.getElementById('cartVacio');
    const cartSummaryEl = document.getElementById('cartSummary');

    // Calcula el valor total del carrito
    function calcularTotal(carrito) {
        return carrito.reduce((total, item) => total + (item.precio * item.cantidad), 0);
    }

    // Pinta la lista de items y el resumen
    function renderCarrito() {
        const carrito = obtenerCarrito();
        const hayItems = carrito.length > 0;

        if (cartVacioEl) cartVacioEl.style.display = hayItems ? 'none' : 'block';
        if (cartSummaryEl) cartSummaryEl.style.display = hayItems ? 'block' : 'none';

        if (!hayItems) {
            cartItemsEl.innerHTML = '';
            if (cartTotalEl) cartTotalEl.textContent = '$ 0';
            if (cartTotalFinalEl) cartTotalFinalEl.textContent = '$ 0';
            return;
        }

        cartItemsEl.innerHTML = carrito.map(item => `
            <div class="cart-item" data-id="${item.id}">
                <img src="${item.imagen ? 'imagenes/' + item.imagen : 'imagenes/logo.png'}" alt="${item.nombre}" class="cart-item-img">
                <div class="cart-item-info">
                    <h3>${item.nombre}</h3>
                    <span class="cart-item-price">${formatearPrecio(item.precio)}</span>
                </div>
                <div class="cart-item-qty">
                    <button class="qty-btn" data-action="decrementar" title="Quitar uno">&minus;</button>
                    <span class="qty-value">${item.cantidad}</span>
                    <button class="qty-btn" data-action="incrementar" title="Añadir uno">+</button>
                </div>
                <span class="cart-item-subtotal">${formatearPrecio(item.precio * item.cantidad)}</span>
                <button class="remove-btn" data-action="eliminar">Eliminar</button>
            </div>
        `).join('');

        const total = formatearPrecio(calcularTotal(carrito));
        if (cartTotalEl) cartTotalEl.textContent = total;
        if (cartTotalFinalEl) cartTotalFinalEl.textContent = total;
    }

    // Delegación de eventos sobre la lista de items
    cartItemsEl.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-action]');
        if (!btn) return;

        const id = btn.closest('.cart-item').dataset.id;
        const action = btn.dataset.action;
        let carrito = obtenerCarrito();

        if (action === 'incrementar') {
            carrito = carrito.map(item => {
                if (String(item.id) === String(id) && item.cantidad < item.stock) {
                    return { ...item, cantidad: item.cantidad + 1 };
                }
                return item;
            });
        } else if (action === 'decrementar') {
            carrito = carrito
                .map(item => String(item.id) === String(id) ? { ...item, cantidad: item.cantidad - 1 } : item)
                .filter(item => item.cantidad > 0);
        } else if (action === 'eliminar') {
            carrito = carrito.filter(item => String(item.id) !== String(id));
        }

        guardarCarrito(carrito);
        renderCarrito();
    });

    // Finalizar compra: simula el pago, avisa y limpia el carrito
    const checkoutBtn = document.getElementById('checkoutBtn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', () => {
            if (totalItems() === 0) {
                mostrarNotificacion('Tu carrito está vacío.');
                return;
            }
            mostrarNotificacion('¡Compra exitosa! Gracias por tu pedido en NeoPulse.');
            localStorage.removeItem(CART_KEY);
            actualizarContadorCarrito();
            renderCarrito();
        });
    }

    // Vaciar carrito
    const vaciarBtn = document.getElementById('vaciarBtn');
    if (vaciarBtn) {
        vaciarBtn.addEventListener('click', () => {
            if (totalItems() === 0) return;
            localStorage.removeItem(CART_KEY);
            actualizarContadorCarrito();
            renderCarrito();
            mostrarNotificacion('Carrito vaciado.');
        });
    }

    renderCarrito();
}
