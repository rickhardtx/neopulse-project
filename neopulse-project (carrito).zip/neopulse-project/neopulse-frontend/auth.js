// ==========================================================================
// CONFIGURACIÓN Y MANEJO DEL MODAL DE AUTENTICACIÓN
// ==========================================================================

const API_BASE_URL = 'http://localhost:8085/api/auth';

// Elementos del DOM
const authModal = document.getElementById('authModal');
const btnIniciarSesion = document.getElementById('btnIniciarSesion');
const closeModal = document.querySelector('.close-modal');

const loginForm = document.getElementById('loginForm');
const registroForm = document.getElementById('registroForm');

// Abrir el modal al presionar "Iniciar sesión"
if (btnIniciarSesion) {
    btnIniciarSesion.addEventListener('click', (e) => {
        e.preventDefault();
        authModal.style.display = 'flex';
    });
}

// Cerrar el modal al presionar la "X"
if (closeModal) {
    closeModal.addEventListener('click', () => {
        authModal.style.display = 'none';
    });
}

// Cerrar el modal si se hace clic fuera del recuadro de contenido
window.addEventListener('click', (e) => {
    if (e.target === authModal) {
        authModal.style.display = 'none';
    }
});

// ==========================================================================
// PROCESAMIENTO DE PETICIONES (FETCH API)
// ==========================================================================

// 1. Envío del Formulario de Registro
if (registroForm) {
    registroForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Captura de datos mapeados exactamente como los espera Jackson en el backend
        const registroData = {
            nombre: document.getElementById('nombre').value,
            correo: document.getElementById('correo').value,
            contrasena: document.getElementById('contrasena').value,
            telefono: document.getElementById('telefono').value // <-- CAMBIO APLICADO AQUÍ
        };

        try {
            const response = await fetch(`${API_BASE_URL}/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(registroData)
            });

            const data = await response.json();

            if (response.ok && data.success) {
                alert(data.message || 'Registro exitoso. Ahora puedes iniciar sesión.');
                registroForm.reset();
            } else {
                alert(`Error: ${data.message || 'No se pudo completar el registro.'}`);
            }

        } catch (error) {
            console.error('Error en la conexión con el servidor:', error);
            alert('Hubo un problema de conexión con el backend de NeoPulse.');
        }
    });
}

// 2. Envío del Formulario de Inicio de Sesión
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Captura de datos para el Map de Spring Boot
        const loginData = {
            loginCorreo: document.getElementById('loginCorreo').value,
            loginContrasena: document.getElementById('loginContrasena').value
        };

        try {
            const response = await fetch(`${API_BASE_URL}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(loginData)
            });

            const data = await response.json();

            if (response.ok && data.success) {
                alert(`${data.message} Bienvenido, ${data.user.nombre}`);
                
                // Guardar la sesión localmente de forma temporal
                localStorage.setItem('neoPulseUser', JSON.stringify(data.user));
                
                // Cerrar modal y limpiar campos
                authModal.style.display = 'none';
                loginForm.reset();
                
                // Aquí puedes actualizar la interfaz, como cambiar el botón de "Iniciar sesión" por el nombre del usuario
                actualizarInterfazUsuario();
            } else {
                alert(`Error: ${data.message || 'Credenciales inválidas.'}`);
            }

        } catch (error) {
            console.error('Error en la conexión con el servidor:', error);
            alert('Hubo un problema de conexión con el backend de NeoPulse.');
        }
    });
}

// Función auxiliar opcional para renderizar el estado del usuario logueado en el Navbar
function actualizarInterfazUsuario() {
    const usuarioGuardado = localStorage.getItem('neoPulseUser');
    if (usuarioGuardado && btnIniciarSesion) {
        const user = JSON.parse(usuarioGuardado);
        btnIniciarSesion.textContent = `Hola, ${user.nombre.split(' ')[0]}`;
        btnIniciarSesion.style.pointerEvents = 'none'; // Deshabilita abrir el modal otra vez si ya está adentro
    }
}

// Ejecutar al cargar la página por si ya hay una sesión activa
document.addEventListener('DOMContentLoaded', actualizarInterfazUsuario);