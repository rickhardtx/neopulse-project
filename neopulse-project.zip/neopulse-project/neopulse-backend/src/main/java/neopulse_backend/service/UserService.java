package neopulse_backend.service;

import neopulse_backend.model.User;
import neopulse_backend.repository.UserRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

/**
 * Servicio encargado de centralizar la lógica de negocio para el módulo de usuarios.
 */
@Service
public class UserService {

    private final UserRepository userRepository;

    // Inyección de dependencias mediante constructor
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Obtiene la lista completa de usuarios registrados en el sistema.
     * @return Lista de entidades User.
     */
    public List<User> getAll() {
        return userRepository.findAll();
    }

    /**
     * Guarda un usuario en la base de datos verificando que el correo no esté duplicado.
     * @param user Objeto con los datos del usuario.
     * @return El usuario guardado con su ID generado.
     */
    public User save(User user) {
        Optional<User> existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser.isPresent()) {
            throw new RuntimeException("El correo electrónico ya se encuentra registrado.");
        }
        return userRepository.save(user);
    }

    /**
     * Valida las credenciales para el inicio de sesión del usuario.
     * @param email Correo electrónico.
     * @param password Contraseña sin encriptar.
     * @return El objeto User si la autenticación es exitosa.
     */
    public User loginUser(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Credenciales incorrectas o usuario no encontrado."));
        
        if (!user.getPassword().equals(password)) {
            throw new RuntimeException("Credenciales incorrectas.");
        }
        
        return user;
    }

    /**
     * Elimina un usuario del sistema mediante su ID.
     * @param id Identificador único del usuario.
     */
    public void delete(Long id) {
        userRepository.deleteById(id);
    }
}