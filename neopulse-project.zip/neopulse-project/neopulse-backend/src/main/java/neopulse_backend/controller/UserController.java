package neopulse_backend.controller;

import neopulse_backend.model.User;
import neopulse_backend.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controlador REST que expone los endpoints HTTP para la gestión de usuarios en NeoPulse.
 * Mapeado bajo la ruta base /api/users
 */
@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5501")
public class UserController {

    private final UserService userService;

    // Inyección del servicio para la manipulación de datos
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Endpoint para consultar todos los usuarios (GET)
     * Ruta: GET http://localhost:8080/api/users
     */
    @GetMapping
    public List<User> getAll() {
        return userService.getAll();
    }

    /**
     * Endpoint para registrar un nuevo usuario (POST)
     * Ruta: POST http://localhost:8080/api/users
     */
    @PostMapping
    public User create(@RequestBody User user) {
        return userService.save(user);
    }

    /**
     * Endpoint crítico para el inicio de sesión (POST)
     * Ruta: POST http://localhost:8080/api/users/login
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginRequest) {
        try {
            User authenticatedUser = userService.loginUser(loginRequest.getEmail(), loginRequest.getPassword());
            // Retorna un estado 200 OK con los datos del usuario si las credenciales son válidas
            return ResponseEntity.ok(authenticatedUser);
        } catch (RuntimeException e) {
            // Retorna un estado 401 Unauthorized junto con el mensaje de error específico
            return ResponseEntity.status(401).body(e.getMessage());
        }
    }

    /**
     * Endpoint para eliminar un usuario por su ID (DELETE)
     * Ruta: DELETE http://localhost:8080/api/users/{id}
     */
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        userService.delete(id);
    }
}