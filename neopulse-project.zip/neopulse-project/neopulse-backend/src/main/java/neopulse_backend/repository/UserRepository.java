package neopulse_backend.repository;

import neopulse_backend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Interfaz que gestiona las operaciones CRUD de la entidad User.
 * Hereda las funciones de Spring Data JPA para interactuar con MySQL.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    // Al heredar de JpaRepository, ya incluye automáticamente: save(), findAll(), deleteById(), etc.

    /**
     * Busca un usuario en la base de datos mediante su correo electrónico.
     * @param email Correo electrónico del usuario.
     * @4f7cf0a8 Un contenedor Optional que puede incluir al usuario si existe.
     */
    Optional<User> findByEmail(String email);
}