/**
 * Lógica de Interfaz y Conexión para el Módulo de Usuarios - NeoPulse
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Capturar los elementos de la interfaz (DOM)
    const modal = document.getElementById('authModal');
    const btnAbrir = document.getElementById('btnIniciarSesion');
    const btnCerrar = document.querySelector('.close-modal');
    const registroForm = document.getElementById('registroForm');

    // ==========================================
    // CONTROL DEL MODAL (ABRIR / CERRAR)
    // ==========================================
    
    // Abrir Modal al dar clic en "Iniciar sesión"
    if (btnAbrir) {
        btnAbrir.addEventListener('click', (e) => {
            e.preventDefault(); // Evita que la página salte o recargue
            modal.style.display = 'flex'; // Activa el contenedor flotante
        });
    }

    // Cerrar Modal al dar clic en la equis (X)
    if (btnCerrar) {
        btnCerrar.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    }

    // Cerrar Modal automáticamente si hacen clic por fuera de la tarjeta
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // ==========================================
    // ENVÍO DE DATOS AL BACKEND (SPRING BOOT)
    // ==========================================
    if (registroForm) {
        registroForm.addEventListener('submit', async (e) => {
            e.preventDefault(); // Intercepta el envío nativo del formulario

            // Capturar los valores de los inputs de VS Code
            const name = document.getElementById('nombre').value;
            const email = document.getElementById('correo').value;
            const password = document.getElementById('contrasena').value;

            // Construir el objeto JSON respetando exactamente la entidad de NetBeans (User.java)
            const usuarioData = {
                name: name,
                email: email,
                password: password
            };

            try {
                // Hacer la petición asíncrona mediante Fetch API al endpoint del Backend
                const response = await fetch('http://localhost:8085/api/users', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(usuarioData)
                });

                // Validar la respuesta del servidor local
                if (response.ok) {
                    const usuarioCreado = await response.json();
                    
                    // Alerta de éxito con el nombre retornado por la base de datos
                    alert(`¡Registro exitoso en NeoPulse, bienvenido(a) ${usuarioCreado.name}! 🚀`);
                    
                    registroForm.reset(); // Limpiar las cajas de texto
                    modal.style.display = 'none'; // Cerrar el modal automáticamente
                    
                } else {
                    alert('Error en el servidor al intentar registrar el usuario. Revisa la consola.');
                }
            } catch (error) {
                console.error('Error en la comunicación Full Stack:', error);
                alert('No se pudo conectar con el backend de Spring Boot. Asegúrate de que esté corriendo en el puerto 8085.');
            }
        });
    }
});